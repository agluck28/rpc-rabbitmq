try:
    from RabbitRpc import RabbitRpcClient, RabbitRpcServer
    from RpcBaseMethod import RpcBaseMethod
    from RpcBaseMethod import RpcBaseMethod
except:
    from .RabbitRpc import RabbitRpcClient, RabbitRpcServer
    from .RpcBaseMethod import RpcBaseMethod
    from .RpcBaseMethod import RpcBaseMethod
